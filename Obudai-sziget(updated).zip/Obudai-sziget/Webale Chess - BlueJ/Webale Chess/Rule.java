// Created and wrote by [Muhammad Din Bin Khairul Izman]

public class Rule {

    public static Player playerR;
    public static Player playerB;
    public static Piece selectedTilePiece;

    // Constructor
    // playerR's turn is set to true because playerR will always starts first when a new game is created.
    public Rule(){
        playerR = new Player('R', true);
        playerB = new Player('B', false);
        selectedTilePiece = null;
    }

    // Swapping the Triangles and Pluses
    public static void swapPiece() {
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 7; c++) {
                if (playerR.getMoveCount() %2 == 0 && playerR.getTurn()) {  //if playerR moved 2 turns
                    if (Board.board[r][c].equals("TrR")) {                  //if the tile is equals to Red Triangle
                        Board.board[r][c] = "PlR";                          //change the tile to Red Plus
                    } else if (Board.board[r][c].equals("PlR")) {           //if the tile is equals to Red Plus
                        Board.board[r][c] = "TrR";                          //change the tile to Red Triangle
                    }
                } else if (playerB.getMoveCount()%2 == 0 && playerB.getTurn()) {    //if playerB moved 2 turns
                    if (Board.board[r][c].equals("TrB")) {                          //if the tile is equals to Blue Triangle
                        Board.board[r][c] = "PlB";                                  //change the tile to Blue Plus
                    } else if (Board.board[r][c].equals("PlB")) {                   //if the tile is equals to Blue Plus
                        Board.board[r][c] = "TrB";                                  //change the tile to Blue Triangle
                    }
                }
            }
        }
    }

    // Checking if the game is over
    public static boolean checkEndGame() {
        boolean sunRExist = false;
        boolean sunBExist = false;
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 7; c++) {
                if (Board.board[r][c].equals("SuB"))    //if the tile is equals to Blue Sun
                    sunBExist = true;                   //set Blue Sun to exist
                if (Board.board[r][c].equals("SuR"))    //if the tile is equals to Red Sun
                    sunRExist = true;                   //set Red Sun to exist
            }
        }
        if (!sunRExist) {   //if Red Sun doesn't exist
            System.out.println("Game over. Blue player win.");
            playerR.setTurn(false);     //not playerR's turn
            playerB.setTurn(false);     //not playerB's turn
            playerB.setWin(true);       //playerB wins
            return true;                //return checkEndGame() to true
        } else if (!sunBExist) {        //if Blue Sun doesn't exist
            System.out.println("Game over. Red player win.");
            playerR.setTurn(false);     //not playerR's turn
            playerB.setTurn(false);     //not playerB's turn
            playerR.setWin(true);       //playerR wins
            return true;                //return checkEndGame() to true
        }
        return false;   //return checkEndGame() to false
    }

    // getter for playerR & playerB
    public static Player getPlayerR() {
        return playerR;
    }

    public static Player getPlayerB() {
        return playerB;
    }

    // Changing the player's turn
    public static void changePlayerTurn() {
        if (Rule.playerR.getTurn()) {           //if playerR's turn is over
            Rule.playerR.setTurn(false);        //not playerR's turn
            Rule.playerB.setTurn(true);         //set to playerB's turn
        } else if (Rule.playerB.getTurn()) {    //if playerB's turn is over
            Rule.playerR.setTurn(true);         //set to playerR's turn
            Rule.playerB.setTurn(false);        //not playerB's turn
        }
    }

}