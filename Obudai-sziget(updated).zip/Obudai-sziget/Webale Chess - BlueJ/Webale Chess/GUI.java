// Created and wrote by [Wan Nurul Azlin Binti Wan Nordin]

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class GUI extends JFrame {

    private static Tile[][] tiles;
    private final JLabel messageLabel;

    // Images (all images are in assets folder)
    // Arrow, Triangle, Chevron have opposite icons, usage when changing direction or flipping board
    private final ImageIcon arrowR = new ImageIcon(new ImageIcon("assets/Arrow_R.png").getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH));
    private final ImageIcon arrowB = new ImageIcon(new ImageIcon("assets/Arrow_B.png").getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH));
    private final ImageIcon arrowRO = new ImageIcon(new ImageIcon("assets/Arrow_R_O.png").getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH));
    private final ImageIcon arrowBO = new ImageIcon(new ImageIcon("assets/Arrow_B_O.png").getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH));
    private final ImageIcon sunR = new ImageIcon(new ImageIcon("assets/Sun_R.png").getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH));
    private final ImageIcon sunB = new ImageIcon(new ImageIcon("assets/Sun_B.png").getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH));
    private final ImageIcon triangleR = new ImageIcon(new ImageIcon("assets/Triangle_R.png").getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH));
    private final ImageIcon triangleB = new ImageIcon(new ImageIcon("assets/Triangle_B.png").getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH));
    private final ImageIcon triangleRO = new ImageIcon(new ImageIcon("assets/Triangle_R_O.png").getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH));
    private final ImageIcon triangleBO = new ImageIcon(new ImageIcon("assets/Triangle_B_O.png").getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH));
    private final ImageIcon plusR = new ImageIcon(new ImageIcon("assets/Plus_R.png").getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH));
    private final ImageIcon plusB = new ImageIcon(new ImageIcon("assets/Plus_B.png").getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH));
    private final ImageIcon chevronR = new ImageIcon(new ImageIcon("assets/Chevron_R.png").getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH));
    private final ImageIcon chevronB = new ImageIcon(new ImageIcon("assets/Chevron_B.png").getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH));
    private final ImageIcon chevronRO = new ImageIcon(new ImageIcon("assets/Chevron_R_O.png").getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH));
    private final ImageIcon chevronBO = new ImageIcon(new ImageIcon("assets/Chevron_B_O.png").getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH));

    public GUI() {
        super("Webale Chess");
        setSize(700, 800);  //set width = 700, height = 800
        setResizable(false);    //set GUI to not resizable
        setLayout(new BorderLayout());
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // Initializing all components
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        JMenuItem newGame = new JMenuItem("New Game");
        JMenuItem saveGame = new JMenuItem("Save Game");
        JMenuItem loadGame = new JMenuItem("Load Game");
        JMenuItem exitGame = new JMenuItem("Exit Game");
        newGame.addActionListener(new NewGameListener());
        saveGame.addActionListener(new SaveGameListener());
        loadGame.addActionListener(new LoadGameListener());
        exitGame.addActionListener(new ExitGameListener());
        fileMenu.add(newGame);
        fileMenu.add(saveGame);
        fileMenu.add(loadGame);
        fileMenu.add(exitGame);
        menuBar.add(fileMenu);
        setJMenuBar(menuBar);
        JPanel boardPanel = new JPanel(new GridLayout(8, 7));
        tiles = new Tile[8][7];
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 7; c++) {
                tiles[r][c] = new Tile();
                tiles[r][c].addActionListener(new TileActionListener());
                if((r+c)%2!=0)  //if every two spaces
                    tiles[r][c].setBackground(Color.LIGHT_GRAY);
                boardPanel.add(tiles[r][c]);
            }
        }
        add(boardPanel, BorderLayout.CENTER);
        JPanel messagePanel = new JPanel();
        messageLabel = new JLabel("Good Luck Have Fun!");
        messagePanel.add(messageLabel);
        add(messagePanel, BorderLayout.SOUTH);
        loadPieceToTile();
        loadBoardToUI();
        setVisible(true);
    }

    private static class Tile extends JButton {
        public Piece chessPiece;
        Tile() {
            chessPiece = null;
        }
    }

    // Loading the piece to tile
    //if at opposite, then Piece(getPlayer(), r, c, true)
    private void loadPieceToTile() {
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 7; c++) {
                switch (Board.board[r][c]) {
                    case "PlB":
                        tiles[r][c].chessPiece = new Plus(Rule.getPlayerB(), r, c, true);
                        break;
                    case "PlR":
                        tiles[r][c].chessPiece = new Plus(Rule.getPlayerR(), r, c, false);
                        break;
                    case "ChB":
                        tiles[r][c].chessPiece = new Chevron(Rule.getPlayerB(), r, c, true);
                        break;
                    case "ChR":
                        tiles[r][c].chessPiece = new Chevron(Rule.getPlayerR(), r, c, false);
                        break;
                    case "SuB":
                        tiles[r][c].chessPiece = new Sun(Rule.getPlayerB(), r, c, true);
                        break;
                    case "SuR":
                        tiles[r][c].chessPiece = new Sun(Rule.getPlayerR(), r, c, false);
                        break;
                    case "ArB":
                        tiles[r][c].chessPiece = new Arrow(Rule.getPlayerB(), r, c, true);
                        break;
                    case "ArR":
                        tiles[r][c].chessPiece = new Arrow(Rule.getPlayerR(), r, c, false);
                        break;
                    case "TrB":
                        tiles[r][c].chessPiece = new Triangle(Rule.getPlayerB(), r, c, true);
                        break;
                    case "TrR":
                        tiles[r][c].chessPiece = new Triangle(Rule.getPlayerR(), r, c, false);
                        break;
                    default:
                        tiles[r][c].chessPiece = null;
                        break;
                }
            }
        }
    }

    // Loading the board to GUI
    // Set Image Icon to each respective piece
    // Set Image Icon for opposite pieces
    private void loadBoardToUI() {
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 7; c++) {
                switch (Board.board[r][c]) {
                    case "PlB":
                        tiles[r][c].setIcon(plusB);
                        break;
                    case "PlR":
                        tiles[r][c].setIcon(plusR);
                        break;
                    case "ChB":
                        if (tiles[r][c].chessPiece.getOpposite()) {
                            tiles[r][c].setIcon(chevronBO);
                        } else {
                            tiles[r][c].setIcon(chevronB);
                        }
                        break;
                    case "ChR":
                        if (tiles[r][c].chessPiece.getOpposite()) {
                            tiles[r][c].setIcon(chevronRO);
                        } else {
                            tiles[r][c].setIcon(chevronR);
                        }
                        break;
                    case "SuB":
                        tiles[r][c].setIcon(sunB);
                        break;
                    case "SuR":
                        tiles[r][c].setIcon(sunR);
                        break;
                    case "ArB":
                        if (tiles[r][c].chessPiece.getOpposite()) {
                            tiles[r][c].setIcon(arrowBO);
                        } else {
                            tiles[r][c].setIcon(arrowB);
                        }
                        break;
                    case "ArR":
                        if (tiles[r][c].chessPiece.getOpposite()) {
                            tiles[r][c].setIcon(arrowRO);
                        } else {
                            tiles[r][c].setIcon(arrowR);
                        }
                        break;
                    case "TrB":
                        if (tiles[r][c].chessPiece.getOpposite()) {
                            tiles[r][c].setIcon(triangleBO);
                        } else {
                            tiles[r][c].setIcon(triangleB);
                        }
                        break;
                    case "TrR":
                        if (tiles[r][c].chessPiece.getOpposite()) {
                            tiles[r][c].setIcon(triangleRO);
                        } else {
                            tiles[r][c].setIcon(triangleR);
                        }
                        break;
                    default:
                        tiles[r][c].setIcon(null);
                        break;
                }
            }
        }
    }

    // Action Listener for Tile
    private class TileActionListener implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent ae) {
            for (int r = 0; r < 8; r++) {
                for (int c = 0; c < 7; c++) {
                    if (ae.getSource() == tiles[r][c]) {
                        System.out.println("Button["+r+"]["+c+"] pressed.\n");
                        if (tiles[r][c].chessPiece!=null) {
                            Player tempPerson = tiles[r][c].chessPiece.getOwner();
                            System.out.println("Tile piece owner is " + tempPerson.getColor());
                        }
                        if (Rule.selectedTilePiece == null && tiles[r][c].chessPiece != null) {
                            if ((Rule.playerR.getTurn() && tiles[r][c].chessPiece.getOwner() == Rule.playerR) ||
                                    (Rule.playerB.getTurn() && tiles[r][c].chessPiece.getOwner() == Rule.playerB)) {
                                System.out.println("Set selected tile.");
                                Rule.selectedTilePiece = tiles[r][c].chessPiece;
                            } else if (!Rule.playerR.getTurn() && tiles[r][c].chessPiece.getOwner() == Rule.playerR) {
                                System.out.println("Reset not your turn.");
                                Rule.selectedTilePiece = null;
                            } else if(!Rule.playerB.getTurn() && tiles[r][c].chessPiece.getOwner() == Rule.playerB) {
                                System.out.println("Reset not your turn.");
                                Rule.selectedTilePiece = null;
                            }
                        } else if (Rule.selectedTilePiece != null && tiles[r][c].chessPiece == Rule.selectedTilePiece) {
                            System.out.println("Reset1");   // Reset1 invoke error when [newR][newC] == [curR][curC]
                            Rule.selectedTilePiece = null;
                        } else if (Rule.selectedTilePiece != null) {
                            // Perform the move for eating opponent's piece
                            if (Rule.selectedTilePiece.movePiece(r, c)) {
                                System.out.println("Moving chess.");
                                Player tempPlayer = Rule.selectedTilePiece.getOwner();
                                if (tempPlayer.getColor() == 'R') {
                                    Rule.playerR.setMoveCount(Rule.playerR.getMoveCount() + 1);
                                } else if (tempPlayer.getColor() == 'B') {
                                    Rule.playerB.setMoveCount(Rule.playerB.getMoveCount() + 1);
                                }
                                tiles[Rule.selectedTilePiece.getCurR()][Rule.selectedTilePiece.getCurC()].chessPiece = null;
                                Rule.selectedTilePiece.setCurR(r);
                                Rule.selectedTilePiece.setCurC(c);
                                tiles[r][c].chessPiece = Rule.selectedTilePiece;
                                swapTile();
                                Rule.swapPiece();
                                Board.flipBoard();
                                Rule.changePlayerTurn();
                                flipTile();
                                loadBoardToUI();
                                if (Rule.playerB.getTurn()) {
                                    messageLabel.setText("Blue Player's Turn");
                                } else {
                                    messageLabel.setText("Red Player's Turn");
                                }
                                setVisible(true);
                            } else {
                                System.out.println("Reset2");   // Reset2 invoke error when invalid move rule
                            }
                            Rule.selectedTilePiece = null;
                        } else if (tiles[r][c].chessPiece == null) {
                            System.out.println("Reset3");   // Reset3 invoke error when no piece was selected (empty tile == [curR][curC])
                            Rule.selectedTilePiece = null;
                        }
                    }
                }
            }
            for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 7; j++) {
                    System.out.print(Board.board[i][j] + " ");
                }
                System.out.println();
            }
            if (Rule.checkEndGame()) {  //if game is over
                if (Rule.playerR.getWin()) {    //if playerR wins
                    messageLabel.setText("Game Over! Red Player Wins");
                } else {                        //if playerB wins
                    messageLabel.setText("Game Over! Blue Player Wins");
                }
            }
            System.out.println("=====================================");
        }
    }

    // Action Listener for New Game
    private class NewGameListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent ae) {
            FileManager.newGame();
            messageLabel.setText("New Game.");
            Rule.playerR = new Player('R', true);
            Rule.playerB = new Player('B', false);
            loadPieceToTile();
            loadBoardToUI();
            setVisible(true);
        }
    }

    // Action Listener for Save Game
    private class SaveGameListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent ae){
            FileManager.saveGame();
            messageLabel.setText("Saved Game.");
        }
    }

    // Action Listener for Load Game
    private class LoadGameListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent ae) {
            boolean[][] oppList = FileManager.loadGame();
            messageLabel.setText("Loaded Game.");
            loadPieceToTile();
            for (int r = 0; r < 8; r++) {
                for (int c = 0; c < 7; c++) {
                    if (tiles[r][c].chessPiece != null) {
                        setPieceOpposite(r, c, oppList[r][c]);
                    }
                }
            }
            loadBoardToUI();
            setVisible(true);
        }
    }

    // Action Listener for Exit Game
    private static class ExitGameListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent ae) {
            System.exit(0);
        }
    }

    public static void flipTile() {
        Piece[][] tempPieceList = new Piece[8][7];
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 7; c++) {
                // For rows, '7' instead of '8' to avoid out of bound error in 2D array.
                // For columns, '6' instead of '7' to avoid out of bound error in 2D array.
                tempPieceList[7 - r][6 - c] = tiles[r][c].chessPiece;
            }
        }
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 7; c++) {
                tiles[r][c].chessPiece = tempPieceList[r][c];
                if (tiles[r][c].chessPiece!=null) {
                    tiles[r][c].chessPiece.refreshLocation(r, c);
                    Player tempPlayer = tiles[r][c].chessPiece.getOwner();
                    if (tempPlayer.getColor() == 'R') {         //if is playerR
                        tiles[r][c].chessPiece.setOwner(Rule.playerR);
                    } else if (tempPlayer.getColor()=='B') {    //if is playerB
                        tiles[r][c].chessPiece.setOwner(Rule.playerB);
                    }
                }
            }
        }
    }

    // Swap Pluses and Triangles
    public static void swapTile() {
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 7; c++) {
                if (Rule.playerR.getMoveCount() % 2 == 0 && Rule.playerR.getTurn()) {           //if every 2 turns is over and is playerR's turn
                    if(Board.board[r][c].equals("TrR")) {
                        tiles[r][c].chessPiece = new Plus(Rule.getPlayerR(), r, c, true);
                    } else if (Board.board[r][c].equals("PlR")) {
                        tiles[r][c].chessPiece = new Triangle(Rule.getPlayerR(), r, c, false);
                    }
                } else if (Rule.playerB.getMoveCount() % 2 == 0 && Rule.playerB.getTurn()) {    //if every 2 turns is over and is playerB's turn
                    if (Board.board[r][c].equals("TrB")) {
                        tiles[r][c].chessPiece = new Plus(Rule.getPlayerB(), r, c, true);
                    } else if (Board.board[r][c].equals("PlB")) {
                        tiles[r][c].chessPiece = new Triangle(Rule.getPlayerB(), r, c, false);
                    }
                }
            }
        }
    }

    // Method to check if the piece is opposite
    public static boolean getPieceOpposite(int r, int c) {
        return tiles[r][c].chessPiece.getOpposite();
    }

    // Method to set the piece to opposite
    public static void setPieceOpposite(int r, int c, boolean opp) {
        tiles[r][c].chessPiece.setOpposite(opp);
    }

    // Method for getPiece
    public static Piece getPiece(int r, int c) {
        return tiles[r][c].chessPiece;
    }

}