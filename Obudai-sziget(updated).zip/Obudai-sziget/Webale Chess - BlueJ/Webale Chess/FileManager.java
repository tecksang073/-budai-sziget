// Created and wrote by [Ungku Harith Arsyad Bin Ungku Ibrahim]

import java.util.*;
import java.io.*;
import java.io.File;
import java.io.PrintWriter;

public class FileManager {

    // Creates a new game
    public static void newGame() {
        Board.board = new String[][]{
                {"PlB", "TrB", "ChB", "SuB", "ChB", "TrB", "PlB"},
                {"ArB", "   ", "ArB", "   ", "ArB", "   ", "ArB"},
                {"   ", "   ", "   ", "   ", "   ", "   ", "   "},
                {"   ", "   ", "   ", "   ", "   ", "   ", "   "},
                {"   ", "   ", "   ", "   ", "   ", "   ", "   "},
                {"   ", "   ", "   ", "   ", "   ", "   ", "   "},
                {"ArR", "   ", "ArR", "   ", "ArR", "   ", "ArR"},
                {"PlR", "TrR", "ChR", "SuR", "ChR", "TrR", "PlR"}
        };
        System.out.println("Created New Game.");
    }

    // Saves the current playing game
    public static void saveGame() {
        File file = new File("saveFile.txt");   //path name for the save file of the game in .txt form
        PrintWriter writer; //used to print the formatted representation of objects to the text-output stream.
        try {
            writer = new PrintWriter(file); //set file path to saveFile.txt
            writer.println(Rule.playerR.getMoveCount());    //save playerR's move count
            writer.println(Rule.playerR.getTurn());         //save playerR's current turn
            writer.println(Rule.playerB.getMoveCount());    //save playerB's move count
            writer.println(Rule.playerB.getTurn());         //save playerB's current turn
            for (int r = 0; r < 8; r++) {   //prints for 2D array
                for (int c = 0; c < 7; c++) {
                    if (Board.board[r][c].equals("   "))    //if current position is an empty tile
                        writer.print(" 0 " + " ");
                    else
                        writer.print(Board.board[r][c] + " ");
                }
                writer.print("\n");
            }
            for (int r = 0; r < 8; r++) {   //prints for GUI tile array
                for (int c = 0; c < 7; c++) {
                    if (GUI.getPiece(r, c) == null) {
                        writer.print("0" + " ");
                    } else {
                        writer.print(GUI.getPieceOpposite(r, c) + " ");
                    }
                }
                writer.print("\n");
            }
            writer.close();
            System.out.println("Successfully save game.");
        }
        catch (FileNotFoundException e) {   //catch any error when handling saveGame()
            System.out.println("Error occur while saving game to file.");
        }
    }

    // Loads the game
    public static boolean[][] loadGame() {
        File file = new File("saveFile.txt");
        boolean[][] tempOppList = new boolean[8][7];
        Scanner readFile;   //used to read the .txt file
        try {
            readFile = new Scanner(file);   //set file path to saveFile.txt
            Rule.playerR.setMoveCount(readFile.nextInt());          //load playerR's move count
            Rule.playerR.setTurn(readFile.next().equals("true"));   //load playerR's current turn
            Rule.playerB.setMoveCount(readFile.nextInt());          //load playerB's move count
            Rule.playerB.setTurn(readFile.next().equals("true"));   //load playerB's current turn
            for (int r = 0; r < 8 ; r++) {
                for (int c = 0; c < 7; c++) {
                    String chessName = readFile.next();
                    if (chessName.equals("0")) {        //if it's '0'
                        Board.board[r][c] = "   ";      //set current position to an empty tile
                    } else {
                        Board.board[r][c] = chessName;  //set current position to the exact piece
                    }
                }
            }
            for (int r = 0; r < 8; r++) {
                for (int c = 0; c < 7; c++) {
                    String tmpStr = readFile.next();
                    if(tmpStr.equals("true")) {
                        tempOppList[r][c] = true;
                    } else if (tmpStr.equals("false")) {
                        tempOppList[r][c] = false;
                    } else {
                        tempOppList[r][c] = false;
                    }
                }
            }
            System.out.println("Successfully load game.");
        }
        catch (FileNotFoundException e) {   //catch any error when handling loadGame()
            System.out.println("Error occur while loading game from file.");
        }
        return tempOppList;
    }

}
