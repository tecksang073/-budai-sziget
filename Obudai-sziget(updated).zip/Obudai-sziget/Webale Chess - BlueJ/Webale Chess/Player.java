// Created and wrote by [Muhammad Din Bin Khairul Izman]

public class Player{

    private final char color;
    private boolean turn;
    private int moveCount;
    private boolean win;

    // Constructor
    public Player(char color, boolean turn) {
        this.color = color;
        this.turn = turn;
        moveCount = 0;
        win = false;
    }

    // getters & setters
    public char getColor() {
        return color;
    }

    public boolean getTurn() {
        return turn;
    }

    public void setTurn(boolean turn) {
        this.turn = turn;
    }

    public int getMoveCount() {
        return moveCount;
    }

    public void setMoveCount(int moveCount) {
        this.moveCount = moveCount;
    }

    public boolean getWin() {
        return win;
    }

    public void setWin(boolean win) {
        this.win = win;
    }

}
