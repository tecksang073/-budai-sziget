// Created and wrote by [Ganeshkhabilan A/L Loganaden]

public class Sun extends Piece {

    // Constructor
    public Sun(Player owner, int curR, int curC, boolean opposite) {
        super(owner, curR, curC, opposite);
    }

    @Override   //used to override abstract method
    public boolean movePiece(int newR, int newC) {
        int distanceR = Math.abs(newR - curR);  // +ve = down, -ve = up
        int distanceC = Math.abs(newC - curC);  // +ve = right, -ve = left
        if (!(Board.board[curR][curC].charAt(2) == Board.board[newR][newC].charAt(2))) {    //if destination position is not own color piece
            if (distanceR <= 1 && distanceC <= 1) {     //if moving 1 space vertically & horizontally
                Board.board[newR][newC] = Board.board[curR][curC];  //move from current position to destination position
                Board.board[curR][curC] = "   ";    //set current position to empty tile
                return true;
            }
        }
        return false;
    }
}
