// Created and wrote by [Ho Teck Sang]

public class Triangle extends Piece {

    // Constructor
    public Triangle(Player owner, int curR, int curC, boolean opposite) {
        super(owner, curR, curC, opposite);
    }

    @Override   //used to override abstract method
    public boolean movePiece(int newR, int newC) {
        int distanceR = newR - curR; // +ve = down, -ve = up
        int distanceC = newC - curC; // +ve = right, -ve = left
        boolean validMove = true;

        if (Math.abs(distanceR) != Math.abs(distanceC)) {   //if not moving diagonally
            return false;
        }
        if (!(Board.board[curR][curC].charAt(2) == Board.board[newR][newC].charAt(2))) {    //if destination position is not own color piece
            if (distanceR < 0 && distanceC < 0) {   //if moving up & moving left
                for (int i = 1; i < Math.abs(distanceR); i++) {
                    if (!(Board.board[curR-i][curC-i].charAt(2) == ' ')) {
                        return false;
                    }
                }
            } else if (distanceR < 0 && distanceC > 0) {    //if moving up & moving right
                for (int i = 1; i < Math.abs(distanceR); i++) {
                    if (!(Board.board[curR-i][curC+i].charAt(2) == ' ')) {
                        return false;
                    }
                }
            } else if (distanceR > 0 && distanceC < 0) {    //if moving down & moving left
                for (int i = 1; i < Math.abs(distanceR); i++) {
                    if (!(Board.board[curR+i][curC-i].charAt(2) == ' ')) {
                        return false;
                    }
                }
            } else if (distanceR > 0 && distanceC > 0) {    //if moving down & moving right
                for (int i = 1; i < Math.abs(distanceR); i++) {
                    if (!(Board.board[curR+i][curC+i].charAt(2) == ' ')) {
                        return false;
                    }
                }
            }
        } else {
            return false;
        }
        if (validMove) {
            Board.board[newR][newC] = Board.board[curR][curC];  //move from current position to destination position
            Board.board[curR][curC] = "   ";    //set current position to empty tile
            return true;
        } else {
            return false;
        }
    }
}