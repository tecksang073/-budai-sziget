// Created and wrote by [Muhammad Din Bin Khairul Izman]

public class WebaleChess {

    public static void main(String[] args) {

        new Rule();
        new GUI();
    }

}
