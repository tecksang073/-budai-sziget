// Created and wrote by [Ganeshkhabilan A/L Loganaden]
// Design Pattern: Factory Method (Piece)
// Factory objects are [Arrow, Chevron, Plus, Sun, Triangle]

package com.chess.engine.pieces;

import com.chess.engine.player.Player;

public abstract class Piece {

    // making them only accessible in the same package and subclasses.
    protected Player owner;
    protected int curR;
    protected int curC;
    protected boolean opposite;

    // Constructor
    Piece(Player owner, int curR, int curC, boolean opposite) {
        this.owner = owner;
        this.curR = curR;
        this.curC = curC;
        this.opposite = opposite;
    }

    // Refresh the current pieces that needs to change the direction to opposite
    public void refreshLocation(int curR, int curC) {
        this.curR = curR;
        this.curC = curC;
        changeOpposite();
    }

    // getters & setters
    public int getCurR() {
        return curR;
    }

    public void setCurR(int curR) {
        this.curR = curR;
    }

    public int getCurC() {
        return curC;
    }

    public void setCurC(int curC) {
        this.curC = curC;
    }

    public Player getOwner() {
        return owner;
    }

    public void setOwner(Player owner) {
        this.owner = owner;
    }

    public boolean getOpposite() {
        return opposite;
    }

    public void setOpposite(boolean opposite) {
        this.opposite = opposite;
    }

    // Changing the direction to opposites
    public void changeOpposite() {
        opposite = !opposite;
    }

    // Abstract method movePiece()
    abstract public boolean movePiece(int newR, int newC);

}