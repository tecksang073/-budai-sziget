// Created and wrote by [Ho Teck Sang]

package com.chess.engine.pieces;

import com.chess.engine.board.Board;
import com.chess.engine.player.Player;

public class Chevron extends Piece {

    // Constructor
    public Chevron(Player owner, int curR, int curC, boolean opposite) {
        super(owner, curR, curC, opposite);
    }

    @Override   //used to override abstract method
    public boolean movePiece(int newR, int newC) {
        int distanceR = Math.abs(newR - curR);  // +ve = down, -ve = up
        int distanceC = Math.abs(newC - curC);  // +ve = right, -ve = left
        boolean validMove = true;

        if (distanceC == 0) {   //if moving vertically (up/down)
            return false;
        }
        if (distanceR == 0) {   //if moving horizontally (left/right)
            return false;
        }
        if (distanceC > 2) {    //if moving right horizontally more than 2 spaces
            return false;
        }
        if (distanceR > 2) {    //if moving down vertically more than 2 spaces
            return false;
        }
        if (Math.abs(distanceR) == Math.abs(distanceC)) {   //if moving diagonally of any direction
            return false;
        }
        if (!(Board.board[curR][curC].charAt(2) == Board.board[newR][newC].charAt(2))) {    //if destination position is not own color piece
            if (distanceR != 2 && distanceC != 2) {     //if not moving down 2 spaces & not moving right 2 spaces
                if (!(Board.board[newR][newC].charAt(2) == ' ')) {  //if destination is not empty tile
                    return false;
                }
                return false;
            }
        } else {
            return false;
        }

        if (validMove) {
            Board.board[newR][newC] = Board.board[curR][curC];  //move from current position to destination position
            Board.board[curR][curC] = "   ";    //set current position to empty tile
            return true;
        } else {
            return false;
        }
    }

}
