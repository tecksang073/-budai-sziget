// Created and wrote by [Ho Teck Sang]

package com.chess.engine.pieces;

import com.chess.engine.board.Board;
import com.chess.engine.player.Player;

public class Arrow extends Piece {

    // Constructor
    public Arrow(Player owner, int curR, int curC, boolean opposite) {
        super(owner, curR, curC, opposite);
    }

    @Override   //used to override abstract method
    public boolean movePiece(int newR, int newC) {
        int distanceR = newR - curR; // +ve = down, -ve = up
        int distanceC = newC - curC; // +ve = right, -ve = left
        boolean validMove = true;
        if (distanceC != 0 || Math.abs(distanceR) > 2) {    //if not moving vertically (up/down) or moving down more than 2 spaces
            return false;
        }
        if (!(Board.board[curR][curC].charAt(2) == Board.board[newR][newC].charAt(2))) {    //if destination position is not own color piece
            if (opposite) { //check if arrow is pointing opposite direction
                System.out.println("Opposite is true");
            } else {
                System.out.println("Opposite is false");
            }
            if (!opposite && distanceR > 0) {           //if arrow is not opposite and moving down
                return false;
            } else if (opposite && distanceR < 0) {     //if arrow is opposite and moving up
                return false;
            } else {
                if (distanceR == 2) {   //if moving down two spaces
                    if (!(Board.board[curR+1][curC].charAt(2) == ' ')) {    //if destination is not empty tile
                        return false;
                    }
                } else if (distanceR == -2) {   //if moving up two spaces
                    if (!(Board.board[curR-1][curC].charAt(2) == ' ')) {    //if destination is not empty tile
                        return false;
                    }
                }
            }
        } else {
            return false;
        }
        if(validMove) {
            Board.board[newR][newC] = Board.board[curR][curC];  //move from current position to destination position
            Board.board[curR][curC] = "   ";    //set current position to empty tile
            if (newR == 0 || newR == 6) {       //if destination is at the end of the side
                changeOpposite();               //change direction to opposite of the arrow
            }
            return true;
        } else {
            return false;
        }
    }

}
