// Created and wrote by [Ungku Harith Arsyad Bin Ungku Ibrahim]

package com.chess.engine.board;

public class Board {

    // Design Pattern: Singleton
    // Creates a 2D array with the placement of the pieces set with default coordinates of a new game.
    public static String[][] board =
            {
                    {"PlB", "TrB", "ChB", "SuB", "ChB", "TrB", "PlB"},
                    {"ArB", "   ", "ArB", "   ", "ArB", "   ", "ArB"},
                    {"   ", "   ", "   ", "   ", "   ", "   ", "   "},
                    {"   ", "   ", "   ", "   ", "   ", "   ", "   "},
                    {"   ", "   ", "   ", "   ", "   ", "   ", "   "},
                    {"   ", "   ", "   ", "   ", "   ", "   ", "   "},
                    {"ArR", "   ", "ArR", "   ", "ArR", "   ", "ArR"},
                    {"PlR", "TrR", "ChR", "SuR", "ChR", "TrR", "PlR"}
            };

    // Creates an empty 2D array.
    // Flip the board when it's opponent's turn.
    public static void flipBoard(){

        String[][] tempBoard =
                {
                        {"   ", "   ", "   ", "   ", "   ", "   ", "   "},
                        {"   ", "   ", "   ", "   ", "   ", "   ", "   "},
                        {"   ", "   ", "   ", "   ", "   ", "   ", "   "},
                        {"   ", "   ", "   ", "   ", "   ", "   ", "   "},
                        {"   ", "   ", "   ", "   ", "   ", "   ", "   "},
                        {"   ", "   ", "   ", "   ", "   ", "   ", "   "},
                        {"   ", "   ", "   ", "   ", "   ", "   ", "   "},
                        {"   ", "   ", "   ", "   ", "   ", "   ", "   "}
                };

        // making the tempBoard to be the inverted version of the board, used when flipping the board.
        for (int r = 0; r < 8; r++){
            for (int c = 0; c < 7; c++){
                // For rows, '7' instead of '8' to avoid out of bound error in 2D array.
                // For columns, '6' instead of '7' to avoid out of bound error in 2D array.
                tempBoard[7 - r][6 - c] = board[r][c];
            }
        }
        board = tempBoard;
    }

}