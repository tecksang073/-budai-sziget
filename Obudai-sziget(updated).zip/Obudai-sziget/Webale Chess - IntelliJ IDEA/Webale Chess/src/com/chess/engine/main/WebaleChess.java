// Created and wrote by [Muhammad Din Bin Khairul Izman]

package com.chess.engine.main;

import com.chess.engine.board.Rule;
import com.chess.engine.gui.GUI;

public class WebaleChess {

    public static void main(String[] args) {

        // Design Pattern: Singleton
        new Rule();
        new GUI();
    }

}
